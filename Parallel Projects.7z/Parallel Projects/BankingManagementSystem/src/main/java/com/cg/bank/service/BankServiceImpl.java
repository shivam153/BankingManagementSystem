package com.cg.bank.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bank.bean.BankingManagement;
import com.cg.bank.dao.BankDao;

@Service
public class BankServiceImpl implements BankService {
	Random rand = new Random();
	@Autowired
	BankDao bankdao;
	@Override
	public void createAccount(BankingManagement bm) {
		bm.setAccountNumber(rand.nextInt(500));
		bankdao.save(bm);
		
		
	}
	@Override
	public void desposit(int customerId, String password, int amount) {
		BankingManagement bm = (BankingManagement)bankdao.findById(customerId).get();
		//if(bm.getPassword().equals(password)) {
			bm.setAccountBalance(bm.getAccountBalance()+amount);
			bankdao.save(bm);
		//}
		//else {
			//System.out.println("Wrong id");
		//}
		
	}
	@Override
	public void transfer(int custId1, int custId2,String password,int amount) {
		BankingManagement bm1 = (BankingManagement)bankdao.findById(custId1).get();
		BankingManagement bm2 = (BankingManagement)bankdao.findById(custId2).get();
		if(bm1.getPassword().equals(password)&&bm2!=null)
		{
			bm1.setAccountBalance(bm1.getAccountBalance()-amount);
			bm2.setAccountBalance(bm2.getAccountBalance()+amount);
			bankdao.save(bm1);
			bankdao.save(bm2);
		}
		
	}
	@Override
	public void withdraw(int custId,String password,int amount) {
		BankingManagement bm = (BankingManagement)bankdao.findById(custId).get();
		if(bm.getPassword().equals(password)) {
			bm.setAccountBalance(bm.getAccountBalance()-amount);
			bankdao.save(bm);
		}
		else {
			System.out.println("Wrong id");
		}
		
	}
	@Override
	public BankingManagement display(int custId, String password) {
		BankingManagement bm = (BankingManagement)bankdao.findById(custId).get();
		
			return bm;
		
	}
	@Override
	public List<BankingManagement> showAll() {
		// TODO Auto-generated method stub
		return bankdao.findAll();
	}
//	@Override
//	public String getIdByPassword(String password,String customerName) {
//		// TODO Auto-generated method stub
////		BankingManagement bm= bankdao.getIdByPassword(password,customerName);
////		Integer a =bm.getCustomerID();
////		return a.toString();
//		List<BankingManagement> bank =bankdao.findAll();
//		for (BankingManagement banking : bank) {
//			if(banking.getCustomerName().equals(customerName))
//		}
//	}
	@Override
	public boolean login(int accId, String password) {
		// TODO Auto-generated method stub
		BankingManagement bm = (BankingManagement)bankdao.findById(accId).get();
		if(bm.getCustomerID()==accId&&bm.getPassword().equals(password))
		{
			return true;
		}
		else {
		return false;
		}
	}
	
	
	

}
