import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Banking } from './banking';

@Injectable()
export class BankServiceService {

  private url: string;

  constructor(private http: HttpClient) {
    this.url="http://localhost:8099/customers"
   }

   public save(user: Banking)
   {
      this.http.post<Banking>(this.url, user);
   }
}
