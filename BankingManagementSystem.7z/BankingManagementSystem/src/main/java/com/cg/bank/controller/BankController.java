package com.cg.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bank.bean.BankingManagement;
import com.cg.bank.service.BankService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class BankController {
	@Autowired
	BankService bankservice;
	@RequestMapping("/")
	public String home()
	{
		return "hello";
	}
	@RequestMapping("/customers")
	public List<BankingManagement> showAll()
	{
		return bankservice.showAll();
	}
	@RequestMapping(value = "/customers/deposit/{id}/{password}/{amt}", method = RequestMethod.PUT)
	public void deposit(@PathVariable int id,@PathVariable String password,@PathVariable int amt)
	{
		bankservice.desposit(id, password, amt);
	}
	@RequestMapping(value = "/customers",method = RequestMethod.POST)
	public void createAccount(@RequestBody BankingManagement bm)
	{
		System.out.println(bm.toString());
		bankservice.createAccount(bm);
		System.out.println(bm.toString());
	}
	@RequestMapping(value = "/customers/transfer/{custId1}/{custId2}/{password}/{amount}",method = RequestMethod.PUT)
	public void transfer(@PathVariable int custId1,@PathVariable int custId2,@PathVariable String password,@PathVariable int amount) 
	{
		bankservice.transfer(custId1, custId2, password, amount);
	}
	@RequestMapping("/customers/display/{custId}/{password}")
	public BankingManagement display(@PathVariable int custId,@PathVariable String password) {
		return bankservice.display(custId, password);
		
	}
	@RequestMapping(value = "/customers/withdraw/{custId}/{password}/{amount}", method = RequestMethod.PUT)
	public void withdraw(@PathVariable int custId,@PathVariable String password,@PathVariable int amount)
	{
		bankservice.withdraw(custId, password, amount);
	}
	
}
