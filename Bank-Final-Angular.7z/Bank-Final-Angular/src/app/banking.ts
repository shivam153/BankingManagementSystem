export class Banking {
    customerID: number;
    customerName: string;
    customerAge: number;
    phoneNumber: string;
    balance: number = 0;
    password: string;

}
