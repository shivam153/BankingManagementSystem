import { Component, OnInit } from '@angular/core';
import { BankingService } from '../banking.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  constructor(private bankservice: BankingService,private router: Router) { }

  deposit(accountId: number,password: string,amount: number)
  {
    this.bankservice.deposit(accountId,password,amount).subscribe();
    this.router.navigate(['homepage/dashboard']);

  }

  ngOnInit() {
  }

}
