package com.service;



import com.bean.Bean;
import com.dao.AccountDao;

public class AccountService {

	AccountDao dao = new AccountDao();


	public boolean validateAccount(int acc) 
	{
		return dao.validateAccount(acc);
	}
	public void createAccount(Bean bean)
	{
		dao.createAccount(bean);
	}

public double showBalance(int accountId)
	{
	
		return dao.showBalance(accountId);
	}

	public double depositAmount(int accountId1, double depositAmount) 
	{
		return dao.depositAmount(accountId1, depositAmount);
	}

	public double withdrawAmount(int accountId2, double withdrawAmount)
	{
		return dao.withdrawAmount(accountId2, withdrawAmount);
	}
	
	
	public void cashTransfer(int source, int destination, double money) 
	{
	
		 dao.cashTransfer(source,destination,money);
	}
	


	}

