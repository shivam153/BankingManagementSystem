import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Banking } from './banking';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class BankingService {
  private currentId: number;
  private url: string;
  private currpass: string;

  constructor(private http: HttpClient) {
    this.url="http://localhost:8099/customers";
   }

   public createAccount(customer: Banking): Observable<Banking> {
    return this.http.post<Banking>(this.url , customer);
    }

    public deposit(customerId: number,password: string,amount: number)
    {
      return this.http.put<Banking>(this.url + '/deposit/' + customerId + '/' + password + '/' + amount, '')
    }

    public withdraw(customerId: number,password: string,amount: number)
    {
      return this.http.put<Banking>(this.url + '/withdraw/' + customerId + '/' + password + '/' + amount, '')
    }

    public transfer(customerId1: number,customerId2: number,password: string,amount: number)
    {
      return this.http.put<Banking>(this.url + '/transfer/' + customerId1 + '/' + customerId2 + '/' + password + '/' + amount, '' )
    }

    public login(customerId: number,password: string)
    {
      return this.http.get<boolean>(this.url + '/login/' + customerId + '/' + password)
    }

    public setId(id: number)
    {
      this.currentId = id;
    }
    public setpass(pass: string)
    {
      this.currpass=pass;
    }

  /*public createAccount(user: Banking)
   {
      this.http.post<Banking>(this.url, user);
   }*/
}
