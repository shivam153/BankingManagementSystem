import { Banking } from './banking';

describe('Banking', () => {
  it('should create an instance', () => {
    expect(new Banking()).toBeTruthy();
  });
});
