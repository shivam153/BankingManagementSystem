import { Component, OnInit } from '@angular/core';
import { BankingService } from '../banking.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  constructor(private bankservice: BankingService,private router: Router) { }

  withdraw(amount: number)
  {
    let id = this.bankservice.getId();
    let password = this.bankservice.getPass();
    this.bankservice.withdraw(id,password,amount).subscribe();
    this.router.navigate(['homepage/dashboard']);

  }

  ngOnInit() {
  }

}
