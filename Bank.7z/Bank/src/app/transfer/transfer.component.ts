import { Component, OnInit } from '@angular/core';
import { BankingService } from '../banking.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {

  constructor(private bankservice: BankingService,private router: Router) { }

  transfer(accountId1: number,accountId2: number,password: string,amount: number)
  {
    this.bankservice.transfer(accountId1,accountId2,password,amount).subscribe();
    this.router.navigate(['homepage/dashboard']);

  }

  ngOnInit() {
  }

}
