import { Component, OnInit } from '@angular/core';
import { BankingService } from '../banking.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  private accId: string;
  accPass: string;
  constructor(private bankservice: BankingService) { 
  }
 



  ngOnInit() {
    this.accId=this.bankservice.getId();
    this.accPass=this.bankservice.getPass();
    console.log("Dash" +this.accId);
    console.log("Dash" + this.accPass);
  }

}
