export class Banking {
    customerId: number;
    customerName: string;
        customerAge: number;
        phoneNumber: string;
        password: string;
   
}
