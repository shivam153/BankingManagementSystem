import { Component, OnInit } from '@angular/core';
import { BankingService } from '../banking.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  constructor(private bankservice: BankingService,private router: Router) { }

  withdraw(accountId: number,password: string,amount: number)
  {
    this.bankservice.withdraw(accountId,password,amount).subscribe();
    this.router.navigate(['homepage/dashboard']);

  }

  ngOnInit() {
  }

}
