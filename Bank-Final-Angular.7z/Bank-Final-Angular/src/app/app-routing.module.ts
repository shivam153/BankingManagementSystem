import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { TransferComponent } from './transfer/transfer.component';
import { TransactionComponent } from './transaction/transaction.component';



const routes: Routes = [
  { path: '' , component: HomepageComponent},
  { path: 'homepage/dashboard' , component: DashboardComponent},
  { path: 'register' , component: RegisterComponent},
  { path: 'deposit', component: DepositComponent},
  { path: 'withdraw', component: WithdrawComponent},
  { path: 'transfer', component: TransferComponent},
  { path: 'display', component: TransactionComponent}
];
export const routingComponents = [HomepageComponent,DashboardComponent,RegisterComponent,DepositComponent,WithdrawComponent,TransferComponent,TransactionComponent]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})


export class AppRoutingModule { }
