import { Component, OnInit } from '@angular/core';
import { BankingService } from '../banking.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {

  constructor(private bankservice: BankingService,private router: Router) { 
    console.log(this.bankservice.getId());
  }

  transfer(accountId2: string,amount: number)
  {
    let selfAccountId = this.bankservice.getId();
    let password = this.bankservice.getPass();
    this.bankservice.transfer(selfAccountId,accountId2,password,amount).subscribe();
    this.router.navigate(['homepage/dashboard']);

  }

  ngOnInit() {
    console.log(this.bankservice.getId());
  }

}
