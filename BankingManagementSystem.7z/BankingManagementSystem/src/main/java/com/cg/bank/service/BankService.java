package com.cg.bank.service;

import java.util.List;

import com.cg.bank.bean.BankingManagement;

public interface BankService {
	public void createAccount(BankingManagement bm);
	public void desposit(int customerId,String password,int amount);
	public void transfer(int custId1,int custId2,String password,int amount);
	public void withdraw(int custId,String password,int amount);
	public BankingManagement display(int custId,String passwor);
	public List<BankingManagement> showAll();

}
