import { Component, OnInit } from '@angular/core';
import { Banking } from '../banking';
import { BankServiceService } from '../bank-service.service';
import { RouterModule, Router } from '@angular/router';
import { AppRoutingModule } from '../app-routing.module';
import { BankingService } from '../banking.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user = new Banking();

  constructor(private bankservice: BankingService,private router: Router) { }

  createAccount(customerName: string,customerAge: string,phoneNumber: string,password: string)
  {
    
    let a : number = parseInt(customerAge);
    this.user.customerName=customerName;
    console.log(this.user.customerName);
    this.user.customerAge=a;
    this.user.phoneNumber=phoneNumber;
    this.user.password=password;
    //this.user = new Banking(customerName,a,phoneNumber,password);
     this.bankservice.createAccount(this.user).subscribe();
     this.router.navigate(['']);
  }

  ngOnInit() {
  //  this.bankservice.createAccount(data).subscribe(data => {
   //   this.user = data;
  }

}
