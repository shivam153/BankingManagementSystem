package com.bean;
public class Bean 
{
private int accountNumber;
private String name;
private int age;
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
private double balance;
private String phoneNumber;
public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public String getName() 
{
	return name;
}
public void setName(String name) 
{
	 
	        this.name=name;}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	   
	    this.phoneNumber = phoneNumber;
	     
	   
}
@Override
public String toString() {
	return "Bean [accountNumber=" + accountNumber + ", name=" + name + ", age=" + age + ", balance=" + balance
			+ ", phoneNumber=" + phoneNumber + "]";
}


}
