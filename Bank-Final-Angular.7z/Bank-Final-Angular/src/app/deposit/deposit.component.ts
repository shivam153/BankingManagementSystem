import { Component, OnInit } from '@angular/core';
import { BankingService } from '../banking.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  private accId: string;
  private pass: string;
  constructor(private bankservice: BankingService, private router: Router) {

  }
  depositm(amount: number) {
    let id = this.bankservice.getId();
    let password = this.bankservice.getPass();

    console.log(id);
    console.log(password);
    console.log();
    this.bankservice.deposit(id, password, amount).subscribe();
    console.log(this.bankservice.getId());
    // this.accId = this.bankservice.getId();
    // this.pass = this.bankservice.getpass();
    this.router.navigate(['homepage/dashboard']);

  }

  ngOnInit() {



  }



}
