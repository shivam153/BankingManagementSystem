import { Component, OnInit } from '@angular/core';
import { BankingService } from '../banking.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor(private bank: BankingService, private router: Router) { }
  Login(accId: string, pass: string) {
    
    this.bank.setId(accId);
    this.bank.setPass(pass);
    console.log(this.bank.getId());
    console.log(this.bank.getPass());
    this.bank.login((accId), pass).subscribe(
      (isLoggedIn) => {
        if (isLoggedIn) {
         
          this.router.navigate(['homepage/dashboard']);
        }  else {
        this.router.navigate(['']);
      }
      }
    )

  }



  ngOnInit() {
  }

}
