import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Banking } from './banking';
import { Observable } from 'rxjs/internal/Observable';
import { PathLocationStrategy } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class BankingService {
  
  private url: string;

  private loggedInId: string;
  private loggedInPassword:string;
  constructor(private http: HttpClient) {
    this.url="http://localhost:8099/customers";
    console.log("Service constri");
   }

   public createAccount(customer: Banking): Observable<Banking> {
    return this.http.post<Banking>(this.url , customer);
    }

    public deposit(customerId: string,password: string,amount: number): Observable<Banking>
    {
      let url  = this.url + '/deposit/' + customerId + '/' + password + '/' + `${amount}`;
      console.log(url);
      return this.http.put<Banking>(url,'');
    }

    public withdraw(customerId: string,password: string,amount: number)
    {
      let url = this.url + '/withdraw/' + customerId + '/' + password + '/' + `${amount}`;
      return this.http.put<Banking>(url,'')
    }

    public transfer(customerId1: string,customerId2: string,password: string,amount: number)
    {
      let url  = this.url + '/transfer/' + customerId1 + '/' + customerId2 + '/' + password + '/' +  `${amount}`;
      return this.http.put<Banking>(url,'');
    }

    public login(customerId: string,password: string)
    {
      return this.http.get<boolean>(this.url + '/login/' + customerId + '/' + password + '/')
    }

    public display(customerId: string,password: string)
    {
      return this.http.get<Banking>(this.url + '/display/' + customerId + '/' + password)
    }

  public setId(accountId: string) {
    this.loggedInId = accountId;
  }
  public setPass(pass: string) {
    this.loggedInPassword = pass;
  }

  public getId() {
    return this.loggedInId;
  }

  public getPass() {
    return this.loggedInPassword;
  }
  /*public createAccount(user: Banking)
   {
      this.http.post<Banking>(this.url, user);
   }*/
}
