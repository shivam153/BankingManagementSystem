import { Component, OnInit } from '@angular/core';
import { BankingService } from '../banking.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

constructor(private bank: BankingService, private router: Router) { }
  Login(acc: number,pass: string)
  {
    //if(this.bank.login(acc,pass))
    {
      this.bank.setId(acc);
      this.bank.setpass(pass);
      this.router.navigate(['homepage/dashboard']);
    }

  }

 

  ngOnInit() {
  }

}
